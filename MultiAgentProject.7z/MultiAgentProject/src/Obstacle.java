
import java.awt.*;

public class Obstacle extends Region
{
    private static final long serialVersionUID = 1;
    public static final Paint obstacleColor = new Color(255,190,190,150);
        
    public Obstacle(double diam)
    {
        super(obstacleColor, diam);
    }        
}
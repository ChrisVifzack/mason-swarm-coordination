
import java.awt.*;

public class Item extends Region
{
    private static final long serialVersionUID = 1;
    public static final Paint itemColor = new Color(100,200,100);
    public static final Paint itemShineColor = new Color(190,255,190,100);
    
    public double shineSize = 150.0;
           
    public Item()
    {
        super(itemColor, 10.0);            
    }
    
    public Region createShine()
    {
    	return new Region(itemShineColor, shineSize);
    }
}
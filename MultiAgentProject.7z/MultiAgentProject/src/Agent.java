
import sim.display.GUIState;
import sim.engine.*;
import sim.util.*;
import java.awt.*;

import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.util.LinkedList;

import sim.portrayal.*;
import sim.portrayal.simple.OvalPortrayal2D;

public class Agent extends OvalPortrayal2D implements Steppable, Oriented2D
{
	private static final long serialVersionUID = 1;	  

	final static double[] theta = new double[/* 8 */]
	{
		0*(/*Strict*/Math.PI/180),
		45*(/*Strict*/Math.PI/180),
		90*(/*Strict*/Math.PI/180),
		135*(/*Strict*/Math.PI/180),
		180*(/*Strict*/Math.PI/180),
		225*(/*Strict*/Math.PI/180),
		270*(/*Strict*/Math.PI/180),
		315*(/*Strict*/Math.PI/180)
	};
	final static double[] xd = new double[/* 8 */]
    {
	    /*Strict*/Math.cos(theta[0]),
	    /*Strict*/Math.cos(theta[1]),
	    /*Strict*/Math.cos(theta[2]),
	    /*Strict*/Math.cos(theta[3]),
	    /*Strict*/Math.cos(theta[4]),
	    /*Strict*/Math.cos(theta[5]),
	    /*Strict*/Math.cos(theta[6]),
	    /*Strict*/Math.cos(theta[7]),
    };       
    final static double[] yd = new double[/* 8 */]
    {
	    /*Strict*/Math.sin(theta[0]),
	    /*Strict*/Math.sin(theta[1]),
	    /*Strict*/Math.sin(theta[2]),
	    /*Strict*/Math.sin(theta[3]),
	    /*Strict*/Math.sin(theta[4]),
	    /*Strict*/Math.sin(theta[5]),
	    /*Strict*/Math.sin(theta[6]),
	    /*Strict*/Math.sin(theta[7]),
    };

    public String message				= "Hello!";
    public Pose pose 					= null;
    private Double2D homePosition		= null;
    private Double2D lastCentroid		= null;
    private Double2D meanShiftVector	= new Double2D(0,0);
    private Double2D preferredDirection	= new Double2D(0,0);
    private Double2D force				= new Double2D(0,0);
    private double excitement			= 1.0;	// influences velocity    
    private int alliance				= -1;
    private int crashDistance			= 12;
	private int spaceInContainer		= 10;
	private int currentNeighbors 		= 0;
    private boolean dead				= false;
    private boolean atHome				= true;
	private boolean inComfortZone		= true;
	private boolean fullContainer		= false;
	private boolean hasPreference		= false;
	LinkedList<Double2D> meanShiftBuffer = new LinkedList<Double2D>();
	
    // set- and get-functions make variables appear in the Inspector    
    public void setDead(boolean value)			{ dead = value; }
    public void setFullContainer(boolean value)	{ fullContainer = value; }
    public void setAlliance(int value)			{ alliance = value; }
    public void setSpaceInContainer(int value)	{ spaceInContainer = value; }   
    public double orientation2D()			{ return pose.orientation; }    
    public double getOrientation()			{ return orientation2D(); }   
    public double getExcitement()			{ return excitement; }
    public double getForce()				{ return force.length(); } 
    public int getAlliance()				{ return alliance; }
    public int getSpaceInContainer()		{ return spaceInContainer; }
    public int getcurrentNeighbors()		{ return currentNeighbors; }
    public String getMessage()				{ return message; }
    public String getHomePosition()			{ return homePosition.toCoordinates(); }    
//    public String getMeanShiftVector()	{ return meanShiftVector.toCoordinates(); }
    public String getPreferredDirection()	{ return preferredDirection.toCoordinates(); } 
    public boolean isDead()					{ return dead; }
    public boolean isAtHome()				{ return atHome; }
    public boolean isInComfortZone()		{ return inComfortZone; }
    public boolean isFullContainer()		{ return fullContainer; }

        
    public Agent(int orientation, Double2D home) // constructor 
	{
		this.homePosition = home;
		this.pose = new Pose(home, orientation);
	}	
    
    public Agent(int orientation, Double2D homePosition, int alliance) // constructor with alliance
   	{
   		this.homePosition = homePosition;
   		this.pose = new Pose(homePosition, orientation);
   		this.alliance = alliance;
   	}	
    
    // returns direction from agent to the home station
    public int homeSweetHome()
    {
    	double angle = Math.atan2((homePosition.y - pose.position.y), (homePosition.x - pose.position.x));
    	angle = angle * (180/Math.PI);
    	if (angle < 0) angle += 360;
        return (int)Math.round(angle / 45);		
	}
    
    public double[] getVisionCone(Demo demo, double range)
    {
		int orientation = pose.orientation;
		double posX = pose.position.x;
		double posY = pose.position.y;		
    	double dPosX = range;
	    double dPosY = range * Math.tan((demo.cameraFOV/2)*Math.PI/180);
	    
	    // rotate according to agent's orientation
	    double rPosX1 = dPosX*xd[orientation] - dPosY*yd[orientation]; // x' = x*cos(a) - y*sin(a)
	    double rPosY1 = dPosX*yd[orientation] + dPosY*xd[orientation]; // y' = x*sin(a) + y*cos(a)
	    double rPosX2 = dPosX*xd[orientation] + dPosY*yd[orientation]; // x' = x*cos(a) - y*sin(a)
	    double rPosY2 = dPosX*yd[orientation] - dPosY*xd[orientation]; // y' = x*sin(a) + y*cos(a)
	    
	    // for now I just save that as triangular region        
	    double[] visionCone = {posX, posY, posX+rPosX1, posY+rPosY1, posX+rPosX2, posY+rPosY2};    
	    return visionCone;		
	}
    
    // incorporate 'proximity net' concept
    private Bag getNeighborsInRange(Demo demo, double range)
    {    	
    	return demo.agentEnvironment.getNeighborsExactlyWithinDistance(
    			new Double2D(pose.position.x, pose.position.y), range);
    }
	
    private Bag getGroundInSight(Demo demo, double range)
    {    	
    	// calculate actual cone of vision
		double[] cone = getVisionCone(demo, range);	
		
		// create polygon out of the 3 corners in cone
		int[] xPoints = { (int)cone[0], (int)cone[2], (int)cone[4], (int)cone[0] };
	    int[] yPoints = { (int)cone[1], (int)cone[3], (int)cone[5], (int)cone[1] };
		Polygon p = new Polygon(xPoints, yPoints, 4);	
		
		// iteration rectangle (with border treatment)
		int startX = Math.max( 0, p.getBounds().x );
		int startY = Math.max( 0, p.getBounds().y );
		int endX = Math.min( (int)demo.worldWidth - 1, p.getBounds().x + p.getBounds().width );
		int endY = Math.min( (int)demo.worldHeight - 1, p.getBounds().y + p.getBounds().height );
		
		// check for intersection with cone and remove the shadow from shadowGrid		
		for (int i = startX; i <= endX; i++) {
			for (int j = startY; j <= endY; j++) {
				if (p.contains(i, j))				
					demo.shadowGrid.field[i][j] = 1; // remove shadow						
			}
		}		
			
		// search over all objects in the groundEnvironment and check if they reach into the cone of vision	
		Bag allObjects = demo.groundEnvironment.getAllObjects();		
		Bag inSight = new Bag();
		boolean intersected = false;
		for (int index = 0; index < allObjects.numObjs; index++)
        {			
			intersected = false;
			Object object = allObjects.objs[index];
			if(object.getClass() == BaseStation.class) continue; // ignore home base
			Region region = (Region)object; // I only do this because I know there will be only regions
			
			Double2D position = demo.groundEnvironment.getObjectLocation(object);			
			int x = (int)Math.round(position.x - region.getSize() / 2.0);
		 	int y = (int)Math.round(position.y - region.getSize() / 2.0); 	  
			Ellipse2D.Double e = new Ellipse2D.Double(x, y, region.getSize(), region.getSize());
			
			// check for intersections between cone and ellipse
			for (int i = startX; i <= endX; i++) {
				for (int j = startY; j <= endY; j++) {
					if (p.contains(i, j) && e.contains(i, j))
						intersected = true;					
				}
			}	
			if(intersected) inSight.add(object);
        }        	
    	return inSight; // all this objects touch the vision cone
    }		   
    
    // TODO: handle alliance forming better -- (also add splitAlliance function!)
    public void joinAlliance(Demo demo, Bag neighbors)
    {    	
    	for(int i = 0; i < neighbors.numObjs; i++)
        {
    		Agent other = (Agent)(neighbors.objs[i]);
 	        if (!other.dead && (other.alliance != alliance))
 	        {
 	        	alliance = other.alliance;
 	        	break;
            }
        }
    	if (alliance == 0) alliance = demo.random.nextInt(2)+1;			
    }

    // updates 'preferredDirection' and 'excitement'
	public void searchGround(Demo demo)
	{		
		Bag ground = getGroundInSight(demo, demo.cameraRange);		
		if (ground == null || ground.numObjs == 0)
		{
			preferredDirection = new Double2D(0,0);
			excitement = 1;
			return;
		}	
		Double2D pos = new Double2D(0,0);
		int count = 0;	
		// loop over all objects in sight and interpret their color		
		for(int i = 0; i < ground.numObjs; i++)
        {
			Region r = (Region)ground.objs[i];			
			Color color = (Color)r.getColor();
			Double2D location = demo.groundEnvironment.getObjectLocation(r);
			if(location == null) continue;
			
			if (color == Obstacle.obstacleColor)
			{								
				// penalize / discourage this direction				
				Double2D temp = location.subtract(pose.position); // vector from agent to obstacle
				pos = pos.subtract(temp);					
				sendStatusMessage("I see an obstacle ...");
				count++;
			}				
			
			if (color == Item.itemShineColor)
			{				
				// promote / encourage this direction			
				Double2D temp = location.subtract(pose.position); // vector from agent to item 
				pos = pos.add(temp);				
				sendStatusMessage("I will check out that interesting looking region!");
				excitement = 3;
				count++;
			}
			
			if (color == Item.itemColor)
			{
				// collect on arrival and not on sight				
				if (pose.position.distance(location) < 10) 
				{
					if(spaceInContainer > 0)
					{
						sendStatusMessage("I am collecting the item.");
						spaceInContainer =- (int)r.getSize();
						demo.groundEnvironment.removeObjectsAtLocation(location);
					}
					if(spaceInContainer <= 0)
						fullContainer = true;						
				}
				else
					sendStatusMessage("I can see an item!");
			}
					
        }		
		if (count > 0) // average    	
			preferredDirection = new Double2D(pos.x/count, pos.y/count);
	    else preferredDirection = new Double2D(0,0);
	}
	
	// returns a vector pointing from the agent to the estimated centroid
	public Double2D calculateCentroid(Bag neighbors)
    {
		// note that calculation only takes agents in the same alliance into account
		double count = 0;
	    Double2D pos = new Double2D(0,0);
	    if (neighbors == null || neighbors.numObjs == 0) return pos;
	    
	    for(int i = 0; i < neighbors.numObjs; i++)
        {
	        Agent other = (Agent)(neighbors.objs[i]);
	        if (!other.dead && (other.alliance == alliance))
	        {
	        	Double2D temp = other.pose.position.subtract(pose.position);
	        	pos = pos.add(temp);	        	
	        	count++;
            }
        }
	    if (count > 0) // average
	        return new Double2D((pos.x/count), pos.y/count);
	    return pos;
    }
	
	public void updateMeanShiftVector(Demo demo, Double2D centroidPosition)
	{
		Double2D bufferedMeanShift = new Double2D(0,0);
		
		meanShiftVector = centroidPosition.subtract(lastCentroid); // vector from last- to current-centroid
		meanShiftBuffer.add(meanShiftVector);	
	
		for(Double2D vector : meanShiftBuffer){
		    bufferedMeanShift = bufferedMeanShift.add(vector);
		}
		
		int bufferSize = meanShiftBuffer.size();
		bufferedMeanShift = new Double2D(bufferedMeanShift.x/bufferSize, bufferedMeanShift.y/bufferSize);
							
		if(demo.useBufferedMeanShift)
			meanShiftVector = bufferedMeanShift;
			
		if (meanShiftBuffer.size() >= demo.meanShiftBufferSize)							
			meanShiftBuffer.remove();
	}
	
	// resembles cohesion-rule known from the flocking heuristics  	
	public Double2D cohesionForce(Demo demo, Double2D centroid)
    {
		// attraction force is proportional to the distance (more sophisticated potential function is possible)
		Double2D force = centroid;
		
		// model comfort zone
		if (force.length() > demo.selfConfidence)	return force;
		else return new Double2D(0,0);
    }
	
	// resembles separation-rule known from the flocking heuristics  
	public Double2D avoidanceForce(Demo demo, Bag neighbors)
    {		
		// the overall 'avoidanceForce' is a vector calculated from pairwise-repulsive forces	
		// which include dead agents and agents from other alliances	
		double count = 0;
		Double2D force = new Double2D(0,0);		
		if (neighbors == null || neighbors.numObjs == 0) return force;    
	    
	    for(int i = 0; i < neighbors.numObjs; i++)
        {
	        Agent other = (Agent)(neighbors.objs[i]);
	        if (other != this)
	        {	        	
	            Double2D dist = other.pose.position.subtract(pose.position);	            
	            if (dist.length() < demo.minAgentDistance) // threshold repulsive (avoidance) force
	            {
	            	double m = 100000 * (1/dist.length() - 1/demo.radarRange) * (1/dist.length() - 1/demo.radarRange);	                    
	            	force = force.add(new Double2D(m * Math.cos(dist.angle()), m * Math.sin(dist.angle())));         
		            count++;
	            }	            
            }
        }
	    if (count > 0) // average
	    	return new Double2D(-(force.x/count), -force.y/count);
	    else return force.negate();	 						
    }
	
	public void updateForces(Demo demo, Bag nearbyAgents)
	{
		Double2D centroid = calculateCentroid(nearbyAgents);
		
		// get flocking-based guidance forces
		force = new Double2D(0,0);
		if (demo.forcesEnabled)
		{
			// Note that the centroid is only used to compute the attraction force 
			// and not for the repulsive force because we use pairwise-avoidance.
			Double2D attrF = cohesionForce(demo, centroid);	
			Double2D repF = avoidanceForce(demo, nearbyAgents);					
			// merge remaining forces to one overall force
			force = repF.add(attrF); // new Double2D(aF.x + cF.x, aF.y + cF.y);
		}
					
		// exploiting the concept of mean-shift theory (where a vector always points to the maximum density)
		Double2D centroidPos = centroid.add(pose.position);	
		if (demo.meanShiftEnabled)
		{			
			if(lastCentroid == null)
			{ 
				lastCentroid = centroidPos;
			}						
			updateMeanShiftVector(demo, centroidPos);
			preferredDirection = preferredDirection.add(meanShiftVector.multiply(demo.meanShiftInfluence));			
		}	
		lastCentroid = centroidPos;
	}
	
	// implements state machine
	public void step(final SimState state) // from steppable
    {
		Demo demo = (Demo)state;
		
		// in case user has moved the object manually
		Double2D position = demo.agentEnvironment.getObjectLocation(this);
		pose.setPosition(new Double2D(position.x, position.y));	
		
		// agent may randomly die
		if (demo.random.nextBoolean(demo.deathProbability)) dead = true;		
		if(dead) return;
		
		// check if agent is at home
		if (pose.position.distance(homePosition) < 10) atHome = true;
		else atHome = false;
					
		// get surrounding for other agents
		Bag nearbyAgents = getNeighborsInRange(demo, demo.radarRange);
		currentNeighbors = nearbyAgents.numObjs - 1;
		if (alliance == 0 && currentNeighbors > 0 && !fullContainer)
		{
			joinAlliance(demo, nearbyAgents);		
		}
		
    	// TODO: somewhere here could be a collision check

		// check ground in sight, update forces and mean-shift vector
        searchGround(demo);	
        updateForces(demo, nearbyAgents);         

        // set values for state machine
        if (preferredDirection.length() > 0) hasPreference = true;
		else hasPreference = false;
    	if(force.length() > 0) inComfortZone = false;
		else inComfortZone = true;
		
		// state machine
		if (atHome && fullContainer) // unloading container
		{
			// unloadContainer();
			sendStatusMessage("Unloading ...");
			spaceInContainer = 10;
			fullContainer = false;		
		}		
		else if (fullContainer) // return to home base if container is full
		{
			// goHome();
			sendStatusMessage("Screw you guys, I'm going home.");	
			excitement = 0.5;
			pose.orientation = homeSweetHome();
			alliance = 0;		
		}	
		else // exploration state
		{					
			double angleF = force.angle() * (180/Math.PI);	
			if (angleF < 0) angleF += 360;
			int orientationF = (int)Math.round((angleF / 45)); // map to discrete orientation
			
			double angleP = preferredDirection.angle() * (180/Math.PI);			
			if (angleP < 0) angleP += 360;
			int orientationP = (int)Math.round(angleP / 45);				
			
			if (demo.idlingEnabled && !inComfortZone && hasPreference &&
				(orientationF - orientationP == 4 || orientationF - orientationP == -4)) // might idle
			{
				// TODO: use distance function instead of this primitive contradiction check!
				excitement = 0; // sometimes doing nothing is the best choice				
				sendStatusMessage("I am struggeling.");					
			}
			else if(demo.forcesEnabled  && !inComfortZone) // use forces
			{				
				sendStatusMessage("I do what the force wants.");
				pose.orientation = orientationF;			
			}
			else if (inComfortZone && hasPreference) // use preference 
			{
				sendStatusMessage("I am following my instinct.");
				pose.orientation = orientationP;							
			}		
			else // random walk	
			{
				sendStatusMessage("Neither force nor preference -- I am moving randomly.");			
				excitement = 1;
				pose.orientation += demo.random.nextInt(3) - 1; // -1,0,1				
			}		
		}
		
		// general randomness
		if (demo.randomnessEnabled && demo.random.nextBoolean(demo.randomness)) 
		{
			sendStatusMessage("Randomness!!");
			pose.orientation += demo.random.nextInt(3) - 1; // -1,0,1
		}
		
		// orientation overflow treatment
		if (pose.orientation > 7) pose.orientation = 0;
        if (pose.orientation < 0) pose.orientation = 7;	
                   
        // update position
		pose.setPosition(new Double2D(pose.position.x + xd[pose.orientation]*excitement,
				  					  pose.position.y + yd[pose.orientation]*excitement));			
	
		// border treatment
        if (pose.position.x >= demo.worldWidth) pose.setPositionX(demo.worldWidth - 1);
        else if (pose.position.x < 0) pose.setPositionX(0);;
        if (pose.position.y >= demo.worldHeight) pose.setPositionY(demo.worldHeight - 1);
        else if (pose.position.y < 0) pose.setPositionY(0); 		
		        	
        // finally, apply the next step
        demo.agentEnvironment.setObjectLocation(this, new Double2D(pose.position.x,pose.position.y));  
    }

	private void sendStatusMessage(String message)
	{
		this.message = message;
	}
	
	@Override
    public final void draw(Object object, Graphics2D graphics, DrawInfo2D info)
    {
		// set appearance of agent according to its alliance
		Color agentColor;	
		if (dead)
			agentColor = Color.black;
		else
	    	switch(alliance)
	    	{
	    		case 1: agentColor = Color.red; break;
	    		case 2: agentColor = Color.blue; break;
	    		case 3: agentColor = Color.green; break;
	    		default: agentColor = Color.gray;
	    	}	    
	    
 	    // System.out.println(info.draw.x + ":" + info.draw.y + ", " + info.location );    
 	    // compensate for offset between 'windowSize' and 'worldSize' here manually
		// (but I guess there might be a better way)
 	    double[] cone = getVisionCone((Demo)info.gui.state, ((Demo)info.gui.state).cameraRange);	    
 	    int offX = (int)(info.draw.x - cone[0]);
 	    int offY = (int)(info.draw.y - cone[1]); 	    
	    int[] xPoints = {(int)cone[0]+offX, (int)cone[2]+offX, (int)cone[4]+offX, (int)cone[0]+offX};
	    int[] yPoints = {(int)cone[1]+offY, (int)cone[3]+offY, (int)cone[5]+offY, (int)cone[1]+offY};
	    graphics.setColor(new Color(240,200,50,120));	    
	    graphics.fillPolygon(xPoints, yPoints, 4);	

		// drawn main body of agent
    	int x = (int)(info.draw.x - crashDistance / 2.0);
 	    int y = (int)(info.draw.y - crashDistance / 2.0); 	   
 	    graphics.setColor(agentColor);
	    graphics.fillOval(x, y, crashDistance, crashDistance); 		    
	    
	    if (info.selected) 
	    {
	    	// draw range or radar as blue circle		    
	 	    double range = ((Demo)info.gui.state).radarRange * 2;	 	
	 	    x = (int)(info.draw.x - range / 2.0);
	 	    y = (int)(info.draw.y - range / 2.0); 	  
	 	    Ellipse2D.Double sensorEllipse = new Ellipse2D.Double(x, y, range, range);
	 	    graphics.setColor(Color.BLUE);
	 	    graphics.draw(sensorEllipse);
	 	    
	 	    // draw line to estimated centroid
	 	    if(lastCentroid != null)
	 	    {	   
	 	    	int dx = (int)(crashDistance / 2.0);
	 	 	    int dy = (int)(crashDistance / 2.0); 	   
		 	    Line2D.Double vector = new Line2D.Double(info.draw.x, info.draw.y, dx+lastCentroid.x, dy+lastCentroid.y);
		 	    graphics.setColor(Color.BLACK);
		 	    graphics.draw(vector);
		 	}
	    }	    
    }
	
	@Override
	public boolean hitObject(Object object, DrawInfo2D info)
    {
	    int width = crashDistance, height = crashDistance;
    	int x = (int)(info.draw.x - width / 2.0);
 	    int y = (int)(info.draw.y - height / 2.0); 	    
 	    Ellipse2D.Double ellipse = new Ellipse2D.Double(x, y, width, height);         
        if (ellipse.intersects( info.clip.x, info.clip.y, info.clip.width, info.clip.height))        
        	return true;       
	    return false;
    }
	
	@Override
	public Inspector getInspector(LocationWrapper wrapper, GUIState state)
	{
		// Here the inspector could be customized
//	    JFrame agentFrame = new JFrame();
//		agentFrame.setTitle("Hello, I am " + ((Agent)wrapper.getObject()).toString());		
//		agentFrame.setBounds(1240, 0, 450, 100);
//		agentFrame.setDefaultCloseOperation(javax.swing.JFrame.DISPOSE_ON_CLOSE);
//	    agentFrame.setVisible(true);	
//		state.controller.registerFrame(agentFrame);
//				
//		JPanel panel = new JPanel();		
//		agentFrame.add(panel);	
//		panel.add(label);
//	    label.setText("I am currently in contact with " + currentNeighbors + " other agent(s)");
	    	
		// then call the normal inspector
		return super.getInspector(wrapper, state);
	}
}



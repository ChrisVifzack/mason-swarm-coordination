
import sim.engine.*;
import sim.util.*;

import sim.field.continuous.*;
import sim.field.grid.*;

public class Demo extends SimState
{
	private static final long serialVersionUID = 1;	
	
	public DoubleGrid2D shadowGrid			= null; // mask over the groundEnvironment
	public Continuous2D groundEnvironment	= null; // field that stores obstacles, rocks, and the homebase
	public Continuous2D agentEnvironment	= null; // field that stores all the agents locations
	
	// parameters of the simulation
	public boolean useBufferedMeanShift	= false;	
	public boolean meanShiftEnabled		= true;
	public boolean forcesEnabled		= true;
	public boolean idlingEnabled		= true;
	public boolean randomnessEnabled	= false;
	public double worldWidth 			= 700;
	public double worldHeight 			= 600;		
	public double spawnDelay 			= 100; // schedule of base station
	public double discretization		= 200; // of agent environment
	public double radarRange			= 130; 	
	public double cameraRange			= 30;
	public double cameraFOV				= 50; 
	public double randomness			= 0.01;
	public double meanShiftInfluence	= 4.0;
	public double deathProbability		= 0.000001; // because shit happens sometimes
	public int numAgents				= 3;
	public int numItems					= 1;
	public int numObstacles				= 0;
	public int selfConfidence			= 60; // threshold for agent's need to stay to the others
	public int minAgentDistance 		= 20; // threshold for agent's need to stay away
	public int repForce 				= 120;
	public int meanShiftBufferSize		= 3;
	
	// set- and get-function make variables appear in the 'Model' tab	
	public void setworldWidth(double value)			{ worldWidth = (value < 1920)? value : 1920; }
	public void setworldHeight(double value)		{ worldHeight = (value < 1200)? value : 1200; }
	public void setSpawnDelay(double value)			{ spawnDelay = (value > 0)? value : 0; }	
	public void setFOV(double value)				{ cameraFOV = (value > 0)? value : 0; }	
	public void setRangeOfCamera(double value)		{ cameraRange = (value > 0)? value : 0; }
	public void setRangeOfRadar(double value)		{ radarRange = value; }
	public void setMeanShiftInfluence(double value)	{ meanShiftInfluence = value; }
	public void setRandomness(double value)			{ if (value >= 0.0 && value <= 1.0) randomness = value; }
    public void setDeathProbability(double value)	{ if (value >= 0.0 && value <= 1.0) deathProbability = value; }
	public void setNumberOfAgents(int value)		{ numAgents = (value <= 100)?  value : 100; }
	public void setNumberOfItems(int value)			{ numItems = (value <= 100)?  value : 100; }
	public void setNumberOfObstacles(int value)		{ numObstacles = (value <= 100)?  value : 100; }
	public void setSelfConfidence(int value)		{ selfConfidence = value; }
	public void setMinAgentDistance(int value)		{ minAgentDistance = value; }
	public void setMeanShiftBufferSize(int value)	{ meanShiftBufferSize = value; }
	public void setIdlingEnabled(boolean value)		{ idlingEnabled = value; }
	public void setRandomnessEnabled(boolean value)	{ randomnessEnabled = value; }
	public void setMeanShiftEnabled(boolean value)	{ meanShiftEnabled = value; }
	public void setForcesEnabled(boolean value)		{ forcesEnabled = value; }
	public void setUseBufferedMeanShift(boolean value)	{ useBufferedMeanShift = value; }
	public double getworldWidth()			{ return worldWidth; }	
	public double getworldHeight()			{ return worldHeight; }	
	public double getSpawnDelay()			{ return spawnDelay; }	
	public double getFOV()					{ return cameraFOV; }	
	public double getRangeOfCamera()		{ return cameraRange; }
	public double getRangeOfRadar()			{ return radarRange; }	
	public double getRandomness()			{ return randomness; }
	public double getMeanShiftInfluence()	{ return meanShiftInfluence; }
	public double getDeathProbability()		{ return deathProbability; }
	public int getNumberOfAgents()			{ return numAgents; }	
	public int getNumberOfItems()			{ return numItems; }	
	public int getNumberOfObstacles()		{ return numObstacles; }
	public int getSelfConfidence()			{ return selfConfidence; }
	public int getMinAgentDistance()		{ return minAgentDistance; }
	public int getMeanShiftBufferSize()		{ return meanShiftBufferSize; }
    public boolean isIdlingEnabled()		{ return idlingEnabled; }    
    public boolean isMeanShiftEnabled()		{ return meanShiftEnabled; }
    public boolean isForcesEnabled()		{ return forcesEnabled; }
    public boolean isRandomnessEnabled()	{ return randomnessEnabled; }
    public boolean isUseBufferedMeanShift()	{ return useBufferedMeanShift; }
   	
	// create a slider in 'Model' tab
	public Object domFOV() 					{ return new sim.util.Interval(0.0, 130.0); }
	public Object domRangeOfCamera()		{ return new sim.util.Interval(0.0, 100.0); } 
	public Object domRangeOfRadar()			{ return new sim.util.Interval(0.0, 500.0); }
	public Object domComfortZone()			{ return new sim.util.Interval(0, 100); }
	public Object domRepForce()				{ return new sim.util.Interval(0, 500); } 
	public Object domMinAgentDistance()		{ return new sim.util.Interval(0, 100); } 
	public Object domRandomness()			{ return new sim.util.Interval(0.0, 1.0); } 
	public Object domMeanShiftInfluence()	{ return new sim.util.Interval(0.0, 50.0); }
	public Object domSelfConfidence()		{ return new sim.util.Interval(0, 100); } 
	
	public Demo(long seed) // constructor
	{
		super(seed);
	}
	
	public void start()
	{		
		super.start();
		
		 // create shadow grid over map
        shadowGrid = new DoubleGrid2D((int)worldWidth, (int)worldHeight, 0);  
		
		// create the field for the agents given discretization, width and height 
		agentEnvironment = new Continuous2D(discretization, worldWidth, worldHeight); 		

		// base station spawns the agents one after another
        BaseStation base = new BaseStation();       
        schedule.scheduleRepeating(base, spawnDelay);
        
        // create the field for the ground
        groundEnvironment = new Continuous2D(worldWidth > worldHeight ? worldWidth : worldHeight, worldWidth, worldHeight);
        
        // initialize ground with random regions of obstacles and items 
        for(int i = 0 ; i < numObstacles; i++)        	
        {
        	Obstacle obstacle = new Obstacle( random.nextInt(50)+20 );
        	groundEnvironment.setObjectLocation(obstacle, new Double2D(random.nextInt((int)worldWidth),
            				     									   random.nextInt((int)worldHeight)));
        }
        for(int i = 0 ; i < numItems; i++) 
        {        	
        	Item item = new Item();
        	Region shine = item.createShine();
        	Double2D itemPosition = new Double2D(random.nextInt((int)worldWidth), random.nextInt((int)worldHeight));        	
        	groundEnvironment.setObjectLocation(shine, itemPosition);
        	groundEnvironment.setObjectLocation(item, itemPosition);
        }             
	}	
		
	public static void main(String[] args)
	{
		doLoop(Demo.class, args);
        System.exit(0);	
	}
}

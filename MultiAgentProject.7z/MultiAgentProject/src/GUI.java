
import sim.engine.*;
import sim.display.*;
import javax.swing.*;
import java.awt.Color;
import java.awt.Graphics2D;

import sim.portrayal.continuous.*;
import sim.portrayal.grid.*;
import sim.portrayal.simple.MovablePortrayal2D;
import sim.portrayal.simple.OvalPortrayal2D;
import sim.portrayal.DrawInfo2D;
import sim.portrayal.Inspector;
import sim.portrayal.LocationWrapper;
import sim.portrayal.SimplePortrayal2D;

public class GUI extends GUIState
{
	public Display2D display;
	public JFrame displayFrame;	
	public int windowWidth = 700;
	public int windowHeight = 600;
	
	FastValueGridPortrayal2D shadowPortrayal = new FastValueGridPortrayal2D("Shadow Grid");	
	ContinuousPortrayal2D groundPortrayal = new ContinuousPortrayal2D();
	ContinuousPortrayal2D agentPortrayal = new ContinuousPortrayal2D();
	
	// makes the inspector 'Model' tab appear in GUI
	public Object getSimulationInspectedObject() { return state; } 
	 
	public GUI()
	{
		super(new Demo(System.currentTimeMillis()));
	}
	
	public GUI(SimState state)
	{
		super(state);
	}
	
	public void setupPortrayals()
	{
		Demo demo = (Demo)state;
		
		 // create shadow map
        shadowPortrayal.setField(demo.shadowGrid);
        shadowPortrayal.setMap(new sim.util.gui.SimpleColorMap(
                0, // shadow
                1, // light                
                Color.black, // new Color(0,0,0,0)
                new Color(0,0,0,0) )); // opaque
        
        agentPortrayal.setField(demo.agentEnvironment);       
        groundPortrayal.setField(demo.groundEnvironment);
  
        shadowPortrayal.setPortrayalForAll(new SimplePortrayal2D() {
        	private static final long serialVersionUID = 1L;
			@Override
        	public boolean hitObject(Object object, DrawInfo2D range) {
        		return false;
        	};        	
		});
        
        agentPortrayal.setPortrayalForAll(
        	new MovablePortrayal2D(
        		new OvalPortrayal2D() {	
					private static final long serialVersionUID = 1L;
					// these functions are handled by the class Agent
        			@Override
					public void draw(Object object, Graphics2D graphics, DrawInfo2D info)
	        		{	((Agent)object).draw(object, graphics, info);		        				
	        		}				
					@Override
					public boolean hitObject(Object object, DrawInfo2D info)
					{	return ((Agent)object).hitObject(object, info);
					}			
					@Override
					public Inspector getInspector(LocationWrapper wrapper, GUIState state)
					{
						return ((Agent)wrapper.getObject()).getInspector(wrapper, state);
					}
				}));
              
        display.reset(); // reschedule the displayer
		display.setBackdrop(Color.white);
		display.repaint(); // redraw the display
	}
	
	public void start()
	{
		super.start();
		setupPortrayals(); // set up our portrayals
	}
	
	public void load(SimState state)
	{
		super.load(state);		
		setupPortrayals(); // set up our portrayals
	}
	
	public void init(Controller c)
	{
		super.init(c);
		
		// customize console window
		Console console = (Console)c;
		console.setBounds(windowWidth + 30, 0, 500, 600);
		
        // create the main display
        display = new Display2D(windowWidth, windowHeight, this);
        displayFrame = display.createFrame();
        displayFrame.setTitle("Demonstration Display");        
        displayFrame.setVisible(true);
        
        c.registerFrame(displayFrame);   // register the frame so it appears in the 'Display' list
        display.attach( groundPortrayal, "Ground" );
        display.attach( shadowPortrayal, "Shadow Grid" );
        display.attach( agentPortrayal, "Agents" );
        
        // delete the scroll bars
        display.display.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
        display.display.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        // when we close the window, the application quits
        displayFrame.setDefaultCloseOperation(javax.swing.JFrame.DISPOSE_ON_CLOSE);        
        displayFrame.setResizable(false);  // can't resize        
        displayFrame.pack(); // the window won't be the right size now -- modify it.         
	}	
	
	public void quit()
    {
	    super.quit();	    
	    if (displayFrame!=null) displayFrame.dispose();
	    displayFrame = null;
	    display = null;
    }
		
	public static void main(String[] args)
	{
		new GUI().createController();
	}
}
	
	
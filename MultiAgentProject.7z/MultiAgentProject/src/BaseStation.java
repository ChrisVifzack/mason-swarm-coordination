import java.awt.Color;
import java.awt.Graphics2D;

import sim.engine.SimState;
import sim.engine.Steppable;
import sim.portrayal.DrawInfo2D;
import sim.portrayal.simple.RectanglePortrayal2D;
import sim.util.Double2D;

public class BaseStation extends RectanglePortrayal2D implements Steppable
{
	private static final long serialVersionUID = 1;	  
	
	public Double2D position = null;		  
	private int curAgents = 0;
	private int alliance = 1;
	
	public BaseStation() 
	{	}	
	
	public void step(final SimState state)
    {	
		Demo demo = (Demo)state;
		
		// base station spawns at random position and attaches itself to the ground
		if (position == null)
		{
			position = new Double2D(demo.random.nextDouble()*demo.worldWidth, demo.random.nextDouble()*demo.worldHeight);
			//position = new Double2D(200.0, 250.0);
			demo.groundEnvironment.setObjectLocation(this, position); 
//			// remove shadow around base station		
//			 for(int i = -23; i <= 22; i++) {
//				for(int j = -23; j <= 22; j++) {
//					demo.shadowGrid.field[(int)position.x+i][(int)position.y+j] = 1;
//				}
//			}
		}
		
		// spawn one agent after another and change alliance after every 5th agent		
		if (alliance > 3) alliance = 1;
		if (curAgents < demo.numAgents)
		{			
			Agent agent = new Agent(demo.random.nextInt(7), position, alliance);
            demo.agentEnvironment.setObjectLocation(agent, new Double2D(agent.pose.position.x,agent.pose.position.y));
            demo.schedule.scheduleRepeating(agent);   
            curAgents++;
            if (curAgents % 5 == 0) alliance++; 
		}		
    }
	
	@Override
    public final void draw(Object object, Graphics2D graphics, DrawInfo2D info)
    {     	
 	    graphics.setColor(new Color(100,255,255,100)); 	    
	    graphics.fillRect((int)info.draw.x-20, (int)info.draw.y-20, 40, 40);			 
    }
}

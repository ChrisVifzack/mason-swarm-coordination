
import sim.util.Double2D;

public class Pose
{
	public Double2D position;
	public int orientation;
	
	public Pose(Double2D position, int orientation)
	{
		this.position = position; 
		this.orientation = orientation;
	}
	
	public void setPosition(Double2D position) { this.position = position; }
	public void setPositionX(double x) { setPosition(new Double2D(x, this.position.y)); }
	public void setPositionY(double y) { setPosition(new Double2D(this.position.x, y)); }
}

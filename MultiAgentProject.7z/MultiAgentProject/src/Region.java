import java.awt.*;
import sim.portrayal.simple.*;

public class Region extends OvalPortrayal2D
{
    private static final long serialVersionUID = 1;
        
    private double size;
    private Paint color;
    
    public Region(Paint c, double diam)
    {
    	super(c, diam); 
    	size = diam; 
        color = c;               
    }
    
    public Paint getColor() { return color; }    
    public double getSize() { return size; }
}